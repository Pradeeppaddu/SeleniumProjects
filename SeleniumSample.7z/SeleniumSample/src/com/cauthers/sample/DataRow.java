package com.cauthers.sample;

public class DataRow {
	String  col1;
	String  col2;
	String  col3;
	String  col4;
	
}
