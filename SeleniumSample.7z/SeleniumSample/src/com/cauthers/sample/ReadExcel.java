package com.cauthers.sample;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import java.util.Iterator;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReadExcel {
	public static void main(String[] args) {
		try {
			FileInputStream fileInputStream = new FileInputStream("E:\\SeleniumCauthers\\src\\com\\cauthers\\ExcelReader\\Shelby County Appeals.xlsx");
			@SuppressWarnings("resource")
			//int count=0;
			XSSFWorkbook workbook = new XSSFWorkbook(fileInputStream);
			XSSFSheet WorkbookSheet = workbook.getSheet("Sheet2");
			XSSFRow row1 = WorkbookSheet.getRow(0);
			Iterator<Row> iterator = WorkbookSheet.iterator();
			
			while (iterator.hasNext()) {
	            Row nextRow = iterator.next();
	            Iterator<Cell> cellIterator = nextRow.cellIterator();
	            //count++;
	            //System.out.println(count);
	            while (cellIterator.hasNext()) {
	            	
	            	 Cell cell=cellIterator.next();
	            	 
	            	 
	            	 
	            	 switch (cell.getCellType()) {
	                    case Cell.CELL_TYPE_STRING:
	                        System.out.print(cell.getStringCellValue());
	                        break;
	                    case Cell.CELL_TYPE_BOOLEAN:
	                        System.out.print(cell.getBooleanCellValue());
	                        break;
	                    case Cell.CELL_TYPE_NUMERIC:
	                        System.out.print(cell.getNumericCellValue());
	                        break;
	                }
	            	 System.out.println("\t");
	            	 	
	            }
	            System.out.println("\n");
			}   
			
		    
		      
             
			//System.out.println(count);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}