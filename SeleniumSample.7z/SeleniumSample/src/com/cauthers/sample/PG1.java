package com.cauthers.sample;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.concurrent.TimeUnit;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.Test;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.cauthers.sample.DataRow;

public class PG1 {


    public static void main(String[] args) throws InterruptedException {
    	
    	prepare();
        
    }
    public static WebElement ElementReady(WebDriver driver, By selector, long timeout){
    	
    	WebElement element = null;
		WebDriverWait wait = new WebDriverWait(driver, timeout);

    	element = wait.until(ExpectedConditions.elementToBeClickable(selector));

    	return element;
    }
    public static void runCode(DataRow cells) throws InterruptedException{
    	// declaration and instantiation of objects/variables
//    	WebDriver driver ;
		System.setProperty("webdriver.chrome.driver","C:\\chromedriver.exe");
		
//		System.setProperty("webdriver.edge.driver","C:\\MicrosoftWebDriver.exe"); //put actual location
//		DesiredCapabilities capabilities = DesiredCapabilities.chrome();
//
//		capabilities.setCapability(CapabilityType.ForSeleniumServer.ENSURING_CLEAN_SESSION, true);
//		capabilities.setCapability("chrome.switches", Arrays.asList("--incognito"));
//		
//		
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--incognito");
		DesiredCapabilities capabilities = DesiredCapabilities.chrome();
		capabilities.setCapability(ChromeOptions.CAPABILITY, options);
		
		ChromeDriver driver = new ChromeDriver();
        String baseUrl = "https://boe.shelbycountytn.gov/eFile/";
        
        // launch Fire fox and direct it to the Base URL
        driver.get(baseUrl);

        
        // Actions
        
        driver.findElement(By.id("j_idt29")).click();
        
        ElementReady(driver, By.className("ui-radiobutton-box"), 1500).click();
        ElementReady(driver, By.id("submit"), 300).click();
        ElementReady(driver, By.id("parId_input"), 5000).sendKeys(cells.col1);
        Thread.sleep(500);
        //driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
        ElementReady(driver, By.id("submit"), 50000).click();
       // ElementReady(driver,By.id("j_idt50:j_idt60"),5000).click();
//        driver.navigate().forward();
        //driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        
        //ElementReady(driver, By.id("parId_input"), 100).sendKeys(Keys.RETURN);
        ElementReady(driver,By.id("j_idt45"), 1500).click();

        ElementReady(driver, By.id("textarea"), 1500).sendKeys(cells.col3);
        ElementReady(driver, By.className("ui-chkbox-box"), 1500).click();
        
        Float val = (float)(Float.parseFloat(cells.col2) * 0.06);
        String val2 = Float.toString(Math.round(val));
        
        System.out.println(val2);
        ElementReady(driver, By.id("cash"), 1500).sendKeys(val2);
        ElementReady(driver, By.id("sign"), 1500).sendKeys("Taylor Caruthers");
        ElementReady(driver,By.id("j_idt78"), 5000).click();
        ElementReady(driver,By.xpath("//*[@id='upl']/div[1]/span"), 3000).click();
        
        driver.switchTo()
        .activeElement()
        .sendKeys("C:\\Users\\prade\\Downloads\\Cauthers\\Updated PDF files\\"+cells.col1+".pdf");
        
        ElementReady(driver,By.id("upldBtn"), 5000).click();
        
       // ElementReady.
        //close Fire fox
         driver.close();
         System.out.println("Succesfully uploaded"+cells.col1);
        // exit the program explicitly
       
        //System.exit(0);
    }
    public static void prepare() throws InterruptedException{
    	try {
			FileInputStream fileInputStream = new FileInputStream("E:\\SeleniumSample\\src\\com\\cauthers\\sample\\Shelby County Appeals.xlsx");
			@SuppressWarnings("resource")
			//int count=0;
			XSSFWorkbook workbook = new XSSFWorkbook(fileInputStream);
			XSSFSheet WorkbookSheet = workbook.getSheet("Sheet2");
			
			//Iterator<Row> iterator = WorkbookSheet.iterator();
			
			int rowLen=WorkbookSheet.getPhysicalNumberOfRows();
//			rowLen=2;
			
			ArrayList<Object> data = new ArrayList<>();
	        for (int i=1;i<rowLen;i++)
	        {
	        	XSSFRow row1 = WorkbookSheet.getRow(i);
	        	System.out.println(row1.getCell(0));
	        	
	        	DataRow cells = new DataRow();
	        	cells.col1 = getCellVal(row1.getCell(0));
	        	cells.col2 = getCellVal(row1.getCell(3));
	        	cells.col3 = getCellVal(row1.getCell(4));
	        	
	        	data.add(cells);
	        	
	        	runCode(cells);
	        	//System.gc();
	        }
//	            Row nextRow = iterator.next();
//	            Iterator<Cell> cellIterator = nextRow.cellIterator();
//	            ArrayList data = null;
//	           
//	            System.out.println(nextRow.getCell(1));
//	            
//	            while (cellIterator.hasNext()) {
//	            	
//	            	 Cell cell=cellIterator.next();
//	            	 
//	            	 
//	            	 
//	            	
//	            	 	
//	            }
//	            System.out.println("\n");
//			}     
			//System.out.println(count);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
    	
    }
    public static String getCellVal(Cell cell){
    	String c = null;
    	switch (cell.getCellType()) {
        case Cell.CELL_TYPE_STRING:
            c = cell.getStringCellValue();
            break;
        case Cell.CELL_TYPE_BOOLEAN:
            c = Boolean.toString(cell.getBooleanCellValue());
            break;
        case Cell.CELL_TYPE_NUMERIC:
            c = Double.toString(cell.getNumericCellValue());
            break;
    }
	return c;
    	
    }
} 


